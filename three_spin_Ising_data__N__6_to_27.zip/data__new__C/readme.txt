Evaluated dataset for examining the critical phenomon in three-spin Ising chain.

h_values = np.linspace(0.8, 1.2, 256)

N = [6, 9, 12, 15, 18, 21, 24, 27]

Correlation:
1. < Z >

Derivative of correlation: 
2. dh_< Z >
3. dh_< Z >_disconnected
4. dh_ < ZZ >_connected
5. dh_< Z0Z >
6. dh_< ZZZ >
7. dh_< XXX >
8. dh_< YYX > = dh_< XYY >
9. dh_< YXY >

Response function:
10. response function for a single site
11. response function for 2-local sites
12. response function for 3-local sites
